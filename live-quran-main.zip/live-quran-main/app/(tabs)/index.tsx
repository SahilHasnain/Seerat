import { colors } from "@/constants/theme";
import { useTabBarVisibility } from "@/contexts/TabBarVisibilityContext";
import { QuranMode, useTrackPlayer } from "@/contexts/TrackPlayerContext";
import { MaterialIcons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { useFocusEffect } from "expo-router";
import React, { useCallback, useState } from "react";
import {
    ActivityIndicator,
    ImageBackground,
    Modal,
    ScrollView,
    StatusBar,
    Text,
    TouchableOpacity,
    TouchableWithoutFeedback,
    View
} from "react-native";

const MODES: { key: QuranMode; label: string }[] = [
  { key: "tilawat", label: "Tilawat" },
  { key: "translation", label: "Translation" },
  { key: "tafseer", label: "Tafseer" },
];

export default function Index() {
  const { showTabBar } = useTabBarVisibility();
  const {
    isPlaying,
    isBuffering,
    isLoading,
    error,
    currentMode,
    currentTrack,
    play,
    pause,
    switchMode,
  } = useTrackPlayer();
  const [showModeMenu, setShowModeMenu] = useState(false);

  // Always show tab bar on Live screen
  useFocusEffect(
    useCallback(() => {
      showTabBar();
    }, [showTabBar]),
  );

  const getModeDisplayName = (mode: QuranMode) => {
    switch (mode) {
      case "tilawat":
        return "Tilawat Radio";
      case "tafseer":
        return "Tafseer Radio";
      case "translation":
        return "Translation Radio";
      default:
        return "Quran Radio";
    }
  };

  const getModeLabel = (mode: QuranMode) => {
    return MODES.find(m => m.key === mode)?.label || "Tilawat";
  };

  const handleModeSwitch = (mode: QuranMode) => {
    if (mode === currentMode) return;
    switchMode(mode);
    setShowModeMenu(false);
  };

  return (
    <ImageBackground
      source={require("@/assets/images/quran-bg.png")}
      style={{ flex: 1 }}
      imageStyle={{ opacity: 0.3 }}
    >
      <View 
        className="absolute inset-0 bg-black/70"
      />
      <StatusBar barStyle="light-content" />

      {/* Mode Dropdown Modal */}
      <Modal
        visible={showModeMenu}
        transparent
        animationType="fade"
        onRequestClose={() => setShowModeMenu(false)}
      >
        <TouchableWithoutFeedback onPress={() => setShowModeMenu(false)}>
          <View className="flex-1 bg-black/50">
            <TouchableWithoutFeedback>
              <View className="absolute top-[72px] right-4 bg-[#1a1a1a] rounded-xl overflow-hidden shadow-lg border border-neutral-800">
                {MODES.map((m, index) => (
                  <TouchableOpacity
                    key={m.key}
                    onPress={() => handleModeSwitch(m.key)}
                    disabled={isLoading}
                    className={`px-4 py-3 flex-row items-center justify-between ${
                      index < MODES.length - 1 ? "border-b border-neutral-800" : ""
                    } ${currentMode === m.key ? "bg-primary/20" : ""} ${
                      isLoading ? "opacity-50" : ""
                    }`}
                    style={{ minWidth: 140 }}
                  >
                    <Text
                      className={`font-medium ${
                        currentMode === m.key ? "text-primary-light" : "text-white"
                      }`}
                    >
                      {m.label}
                    </Text>
                    {currentMode === m.key && (
                      <MaterialIcons name="check" size={18} color={colors.primary.light} />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      {/* Loading Overlay */}
      {isLoading && (
        <View className="absolute inset-0 bg-[#0f0f0f]/95 z-50 items-center justify-center">
          <View className="items-center">
            <Image
              source={require("@/assets/images/headphone-v1.png")}
              style={{ width: 80, height: 80, marginBottom: 24 }}
              resizeMode="contain"
            />
            <ActivityIndicator size="large" color={colors.primary.light} />
            <Text className="text-white/90 text-lg font-semibold mt-4">
              Loading {getModeDisplayName(currentMode)}...
            </Text>
            <Text className="text-neutral-400 text-sm mt-2">Please wait</Text>
          </View>
        </View>
      )}

      {/* Header */}
      <View className="pt-14 pb-5 px-6">
        <View className="flex-row items-center justify-between">
          <View className="flex-row items-center gap-3">
            <Image
              source={require("@/assets/images/icon.png")}
              style={{ width: 32, height: 32 }}
              resizeMode="contain"
            />
            <View>
              <Text className="text-white/90 text-xl font-bold">
                Quran Radio
              </Text>
              {/* Live Badge Below Text */}
              <View className="mt-1 self-start bg-green-500/90 px-2 py-0.5 rounded flex-row items-center">
                <View className="w-1 h-1 bg-white rounded-full mr-1" />
                <Text className="text-white text-[8px] font-bold uppercase tracking-wider">
                  Live
                </Text>
              </View>
            </View>
          </View>
          
          <View className="flex-row items-center gap-3">
            {/* Mode Selector Button */}
            <TouchableOpacity
              onPress={() => setShowModeMenu(!showModeMenu)}
              disabled={isLoading}
              className={`bg-primary px-4 py-2.5 rounded-xl flex-row items-center gap-2 ${
                isLoading ? "opacity-50" : ""
              }`}
              accessibilityLabel="Select mode"
            >
              <Text className="text-white font-semibold text-sm">
                {getModeLabel(currentMode)}
              </Text>
              <MaterialIcons 
                name={showModeMenu ? "keyboard-arrow-up" : "keyboard-arrow-down"} 
                size={20} 
                color="white" 
              />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <ScrollView className="flex-1">
        {/* Now Playing Card */}
        <View className="mx-6 mt-6 mb-6 p-8 items-center">
          {error ? (
            <View className="items-center">
              <View className="w-20 h-20 bg-red-500/10 rounded-full items-center justify-center mb-4">
                <MaterialIcons name="warning" size={48} color="#ef4444" />
              </View>
              <Text className="text-white/90 text-lg font-semibold text-center mb-2">
                Connection Error
              </Text>
              <Text className="text-neutral-500 text-center mb-6 px-4 text-sm">
                {error.message}
              </Text>
              <TouchableOpacity
                onPress={play}
                disabled={isLoading}
                className="bg-primary px-8 py-3 rounded-full"
              >
                {isLoading ? (
                  <ActivityIndicator color="white" />
                ) : (
                  <Text className="text-white font-semibold text-base">
                    Try Again
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          ) : (
            <>
              <View className="w-32 h-32 rounded-full items-center justify-center mb-6">
                <Image 
                  source={require("@/assets/images/headphone-v1.png")}
                  style={{ width: 120, height: 120 }}
                  resizeMode="contain"
                />
              </View>

              {isBuffering && (
                <View className="mb-4 flex-row items-center">
                  <ActivityIndicator color={colors.primary.light} size="small" />
                  <Text className="text-neutral-400 text-xs ml-2">
                    Buffering...
                  </Text>
                </View>
              )}
            </>
          )}
        </View>
      </ScrollView>

      {/* Fixed Play/Pause Button at Bottom Right */}
      <View className="absolute bottom-24 right-6 pb-8">
        <TouchableOpacity
          onPress={isPlaying ? pause : play}
          disabled={isLoading}
          className={`${
            isPlaying ? "bg-primary-dark" : "bg-primary"
          } w-16 h-16 rounded-full items-center justify-center shadow-2xl`}
        >
          <MaterialIcons
            name={isPlaying ? "pause" : "play-arrow"}
            size={36}
            color="white"
          />
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}
